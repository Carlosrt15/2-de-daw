package com.adrian.colegio.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.adrian.colegio.entities.MunicipioEntity;

public interface MunicipioRepository extends CrudRepository<MunicipioEntity, Integer>{

}
